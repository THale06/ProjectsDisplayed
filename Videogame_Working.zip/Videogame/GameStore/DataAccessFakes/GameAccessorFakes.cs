﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataObjects;
using DataAccessInterfaces;

namespace DataAccessFakes
{
    public class GameAccessorFake : IGameAccessor
    {
        private List<GameVM> _gameVMs = new List<GameVM>();

        public GameAccessorFake()
        {
            _gameVMs.Add(new GameVM
            {
                GameID = 999999,
                Title = "Oregon Trail",
                GameStatusID = "Available",
                GameTypeID = "Strategy",
                Active = true
            });
            _gameVMs.Add(new GameVM
            {
                GameID = 999998,
                Title = "Suikoden",
                GameStatusID = "Available",
                GameTypeID = "RPG",
                Active = true
            });
            _gameVMs.Add(new GameVM
            {
                GameID = 999999,
                Title = "Doom",
                GameStatusID = "Fable",
                GameTypeID = "FPS",
                Active = true
            });

            _gameVMs[0].Specifics = new List<string>();
            _gameVMs[0].Specifics.Add("Test 1");
            _gameVMs[0].Specifics.Add("Test 2");
        }

        public List<string> SelectSpecificsByGameTypeID(string gameTypeID)
        {
            List<string> specifics = null;
            if (gameTypeID != "RPG" && gameTypeID != "Strategy" && gameTypeID != "FPS")
            {
                throw new ArgumentException("Invalid Game Type");
            }
            if (gameTypeID == "RPG")
            {
                specifics = _gameVMs[0].Specifics;
            }


            return specifics;
        }

        public List<GameVM> SelectGamesByGameStatusID(string gameStatusID)
        {
            return _gameVMs.Where(c => c.GameStatusID == gameStatusID).ToList();
        }
    }
}
