﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;
using DataObjects;
using DataAccessInterfaces;

namespace DataAccessFakes
{
    public class PlayerAccessorFake : IPlayerAccessor
    {
        private List<Player> fakePlayers = new List<Player>();
        private List<string> passwordHashes = new List<string>();

        public PlayerAccessorFake()
        {
            fakePlayers.Add(new Player()
            {
                PlayerID = 999999,
                Email = "jham@game.com",
                FirstName = "John",
                LastName = "Ham",
                Phone = "3195558888",
                Active = true,
                PlayerTitle = new List<String>()
            });

            fakePlayers.Add(new Player()
            {
                PlayerID = 999998,
                Email = "duplicate@game.com",
                FirstName = "Bad",
                LastName = "Data",
                Phone = "851545154415",
                Active = true,
                PlayerTitle = new List<String>()
            });


            passwordHashes.Add("9c9064c59f1ffa2e174ee754d2979be80dd30db552ec03e7e327e9b1a4bd594e");
            passwordHashes.Add("invalid-hash");
            

            fakePlayers[0].PlayerTitle.Add("Admin");
            fakePlayers[0].PlayerTitle.Add("Manager");
        }


        public int AuthenticatePlayer(string email, string passwordHash)
        {
            int result = 0;

            for (int i = 0; i < fakePlayers.Count; i++)
            {
                if (fakePlayers[i].Email == email && passwordHashes[i] == passwordHash)
                {
                    result++;
                }
            }

            return result;
        }

        public List<string> SelectPlayerTitlesByPlayerID(int playerID)
        {
            List<string> playerTitle = null;

            foreach (var fakePlayer in fakePlayers)
            {
                if (fakePlayer.PlayerID == playerID)
                {
                    playerTitle = fakePlayer.PlayerTitle;
                }
            }

            return playerTitle;
        }

        public Player SelectPlayerByEmail(string email)
        {
            Player player = null;

            foreach (var fakePlayer in fakePlayers)
            {
                if (fakePlayer.Email == email)
                {
                    player = fakePlayer;
                    break;
                }
            }

            if (player == null)
            {
                throw new ApplicationException("User not found.");
            }
            return player;
        }

        public int UpdatePasswordHash(int playerID, string passwordHash, string oldPasswordHash)
        {
            throw new NotImplementedException();
        }
    }
}