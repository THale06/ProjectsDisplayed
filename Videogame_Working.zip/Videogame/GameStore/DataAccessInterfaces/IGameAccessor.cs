﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataObjects;

namespace DataAccessInterfaces
{
    public interface IGameAccessor
    {
        List<GameVM> SelectGamesByGameStatusID(string gameStatusID);
        List<string> SelectSpecificsByGameTypeID(string gameTypeID);
    }
}
