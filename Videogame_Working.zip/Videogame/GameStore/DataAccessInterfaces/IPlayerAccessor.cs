﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataObjects;

namespace DataAccessInterfaces
{
    public interface IPlayerAccessor
    {
        int AuthenticatePlayer(string email, string passwordHash);
        Player SelectPlayerByEmail(string email);
        List<string> SelectPlayerTitlesByPlayerID(int playerID);
        int UpdatePasswordHash(int playerID,
            string passwordHash, string oldPasswordHash);
    }
}

