﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataObjects;
using DataAccessInterfaces;
using System.Data;
using System.Data.SqlClient;

namespace DataAccessLayer
{
    public class GameAccessor : IGameAccessor
    {
        public List<string> SelectSpecificsByGameTypeID(string gameTypeID)
        {
            List<string> specifics = new List<string>();

            //connection
            var ConnectionFactory = new DBConnection();
            var conn = ConnectionFactory.GetDBConnection();

            // command text
            var cmdText = "sp_select_specifics_by_gametypeid";

            // command

            var cmd = new SqlCommand(cmdText, conn);

            // type
            cmd.CommandType = CommandType.StoredProcedure;

            // parameters
            cmd.Parameters.Add("@GameTypeID", SqlDbType.VarChar, 25);
            cmd.Parameters["@GameTypeID"].Value = gameTypeID;

            try
            {
                conn.Open();

                // execute
                var reader = cmd.ExecuteReader();

                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        specifics.Add(reader.GetString(0));
                    }
                }
                else
                {
                    throw new ArgumentException("Invalid Game Type");
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }
            finally
            {
                conn.Close();
            }
            return specifics;

        }

        public List<GameVM> SelectGamesByGameStatusID(string gameStatusID)
        {
            List<GameVM> games = new List<GameVM>();

            // connection
            DBConnection connectionFactory = new DBConnection();
            var conn = connectionFactory.GetDBConnection();

            // command text
            var cmdText = "sp_select_games_by_gamestatusid";

            // create command
            var cmd = new SqlCommand(cmdText, conn);

            // command type
            cmd.CommandType = CommandType.StoredProcedure;

            // parameters
            cmd.Parameters.Add("@GameStatusID", SqlDbType.NVarChar, 25);

            // values
            cmd.Parameters["@GameStatusID"].Value = gameStatusID;

            // try-catch-finally
            try
            {
                conn.Open();

                var reader = cmd.ExecuteReader();

                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        //
                        var game = new GameVM();
                        game.GameID = reader.GetInt32(0);
                        game.Title = reader.GetString(1);
                        game.GameTypeID = reader.GetString(2);
                        game.GameStatusID = reader.GetString(3);
                        game.Active = reader.GetBoolean(4);

                        games.Add(game);
                    }
                }

            }
            catch (Exception ex)
            {

                throw ex;
            }
            finally
            {
                conn.Close();
            }


            return games;
        }
    }
}
