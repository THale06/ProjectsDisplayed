﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DataObjects
{
    public class Game
    {
        public int GameID { get; set; }
        public string Title { get; set; }
        public string GameTypeID { get; set; }
        public string GameStatusID { get; set; }
        public bool Active { get; set; }
    }

    public class GameVM : Game
    {
        public List<string> Specifics { get; set; }
    }
}