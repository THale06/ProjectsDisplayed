﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using DataObjects;
using LogicLayer;

namespace GameStore
{
    /// <summary>
    /// Interaction logic for GameDetailWindow.xaml
    /// </summary>
    public partial class GameDetailWindow : Window
    {
        GameVM _game = null;
        GameManager _gameManager = null;

        public GameDetailWindow(GameVM game, GameManager gameManager)
        {
            _game = game;
            _gameManager = gameManager;
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            txtTitle.Text = _game.Title;
            txtType.Text = _game.GameTypeID;
            txtStatus.Text = _game.GameStatusID;
            lstSpecifics.ItemsSource = _game.Specifics;
        }

        private void btnRent_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = true;
        }

        private void btnCancel_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = false;
        }
    }
}
