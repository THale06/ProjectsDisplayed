﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using LogicLayer;
using DataObjects;

namespace GameStore
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private Player _player = null;
        private List<GameVM> _gamesForRent = null;

        private void btnLogin_Click(object sender, RoutedEventArgs e)
        {
            if ((string)btnLogin.Content == "Log Out")
            {
                _player = null;
                btnLogin.Content = "Login";
                updateUIforLogOut();
                return;  // important not to go on 
            }



            var email = this.txtEmail.Text;
            var password = this.txtPassword.Password;

            if (email.Length < 6)
            {
                MessageBox.Show("Bad email address");
                txtEmail.Text = "";
                txtEmail.Focus();
                return;
            }
            if (password.Length == 0)
            {
                MessageBox.Show("Missing password");
                txtPassword.Password = "";
                txtPassword.Focus();
                return;
            }

            var playerManager = new PlayerManager();


            try
            {
                _player = playerManager.LoginPlayer(email, password);
                MessageBox.Show("Hello, " + _player.FirstName + "\n\n" +
                    "You are logged in as: " + _player.PlayerTitle[0]);

                updateUIforPlayer();
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message + "\n\n" + ex.InnerException.Message);
            }

        }

        private void hideAllPlayerTabs()
        {
            foreach (var tab in tabsetMain.Items)
            {
                ((TabItem)tab).Visibility = Visibility.Collapsed;
            }
        }

        private void frmMain_Loaded(object sender, RoutedEventArgs e)
        {
            updateUIforLogOut();
        }

        private void updateUIforPlayer()
        {

            string playertitlesList = "";

            for (int i = 0; i < _player.PlayerTitle.Count; i++)
            {
                playertitlesList += " " + _player.PlayerTitle[i];
                if (i == _player.PlayerTitle.Count - 2)
                {
                    if (_player.PlayerTitle.Count > 2)
                    {
                        playertitlesList += ",";
                    }
                    playertitlesList += " and ";
                }
                else if (i < _player.PlayerTitle.Count - 2)
                {
                    playertitlesList += ",";
                }
            }
            lblGreeting.Content = "Welcome, " + _player.FirstName + " " + _player.LastName
                + ". You are logged in as " + playertitlesList;


            statMessage.Content = "Logged in on " + DateTime.Now.ToLongDateString()
                + "at " + DateTime.Now.ToShortTimeString()
                + " . Remember to log out before you leave.";


            btnLogin.Content = "Log Out";
            btnLogin.IsDefault = false;
            showTabsForPlayer();

            txtEmail.Text = "";
            txtPassword.Password = "";
            txtEmail.Visibility = Visibility.Hidden;
            txtPassword.Visibility = Visibility.Hidden;
            lblEmail.Visibility = Visibility.Hidden;
            lblPlassword.Visibility = Visibility.Hidden;
        }

        private void updateUIforLogOut()
        {
            tabsetPanel.Visibility = Visibility.Hidden;
            hideAllPlayerTabs();
            btnLogin.IsDefault = true;
            txtEmail.Focus();

            txtEmail.Text = "";
            txtPassword.Password = "";
            txtEmail.Visibility = Visibility.Visible;
            txtPassword.Visibility = Visibility.Visible;
            lblEmail.Visibility = Visibility.Visible;
            lblPlassword.Visibility = Visibility.Visible;

            lblGreeting.Content = "You are not logged in.";
            statMessage.Content = "Welcome. Please login to continue.";

            txtEmail.Focus();
        }

        private void showTabsForPlayer()
        {
            foreach (var role in _player.PlayerTitle)
            {
                
                tabRental.Visibility = Visibility.Visible;
                tabRental.IsSelected = true;
                tabRental.Focus();
                switch (role)
                {
                    case "Admin":
                        tabAdmin.Visibility = Visibility.Visible;
                        tabAdmin.IsSelected = true;
                        break;
                    case "Return":
                        tabCheckin.Visibility = Visibility.Visible;
                        tabCheckin.IsSelected = true;
                        break;
                    case "Checkout":
                        tabCheckout.Visibility = Visibility.Visible;
                        tabCheckout.IsSelected = true;
                        break;
                    case "Inspection":
                        tabInspection.Visibility = Visibility.Visible;
                        tabInspection.IsSelected = true;
                        break;
                    case "Prep":
                        tabPrep.Visibility = Visibility.Visible;
                        tabPrep.IsSelected = true;
                        break;
                    case "Manager":
                        tabManagement.Visibility = Visibility.Visible;
                        tabManagement.IsSelected = true;
                        break;
                    default:
                        break;
                }
            }

            tabsetPanel.Visibility = Visibility.Visible;
        }

        private void tabRental_GotFocus(object sender, RoutedEventArgs e)
        {
            if (_gamesForRent == null)
            {
                populateGamesForRent();

            }
        }

        private void populateGamesForRent()
        {
            try
            {
                GameManager gameManager = new GameManager();
                _gamesForRent = gameManager.RetrieveGamesByStatus("Available");

                dataRental.ItemsSource = _gamesForRent;

                dataRental.Columns.RemoveAt(0);
                dataRental.Columns.RemoveAt(4);
                dataRental.Columns[1].Header = "Game ID";
                dataRental.Columns[2].Header = "Game Type";
                dataRental.Columns[3].Header = "Game Status";

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + "\n\n" + ex.InnerException.Message);
            }
        }

        private void dataRental_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            var selectedGame = (GameVM)(dataRental.SelectedItem);
            try
            {
                GameManager gameManager = new GameManager();
                selectedGame = gameManager.RetrieveSpecificsForGameVM(selectedGame);

                var detailWindow = new GameDetailWindow(selectedGame, gameManager);

                if ((bool)detailWindow.ShowDialog())
                {
                    MessageBox.Show("Records Updated");
                    // code to refresh the list
                    dataRental.ItemsSource = null;
                    populateGamesForRent();

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + "\n\n" + ex.InnerException.Message);
            }

        }
    }
}
