﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataObjects;
using DataAccessInterfaces;
using DataAccessLayer;
using LogicLayerInterfaces;

namespace LogicLayer
{
    public class GameManager : IGameManager
    {
        private IGameAccessor _gameAccessor = null;

        public GameManager()
        {
            _gameAccessor = new GameAccessor();
        }

        public GameManager(IGameAccessor gameAccessor)
        {
            _gameAccessor = gameAccessor;
        }

        public GameVM RetrieveSpecificsForGameVM(GameVM gameVM)
        {
            try
            {
                gameVM.Specifics = _gameAccessor.SelectSpecificsByGameTypeID(gameVM.GameTypeID);

            }
            catch (Exception ex)
            {

                throw new ApplicationException("Specifics list not found", ex);
            }
            return gameVM;
        }

        public List<GameVM> RetrieveGamesByStatus(string status)
        {
            List<GameVM> games = null;

            try
            {
                games = _gameAccessor.SelectGamesByGameStatusID(status);
            }
            catch (Exception ex)
            {

                throw new ApplicationException("Data not found.", ex);
            }

            return games;
        }
    }
}