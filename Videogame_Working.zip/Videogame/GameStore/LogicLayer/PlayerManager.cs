﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataObjects;
using LogicLayerInterfaces;
using DataAccessInterfaces;
using DataAccessLayer;
using System.Security.Cryptography;

namespace LogicLayer
{
    public class PlayerManager : IPlayerManager
    {
        private IPlayerAccessor playerAccessor = null;

        public PlayerManager()
        {
            playerAccessor = new PlayerAccessor();
        }

        public PlayerManager(IPlayerAccessor ua)
        {
            playerAccessor = ua;
        }

        public string HashSha256(string source)
        {
            string result = "";

            if (source == "" || source == null)
            {
                throw new ArgumentException("Source can't be empty");
            }



            // create a byte array
            byte[] data;

            // create a .NET hash provider object
            using (SHA256 sha256hasher = SHA256.Create())
            {
                // hash the input
                data = sha256hasher.ComputeHash(Encoding.UTF8.GetBytes(source));
            }
            // create a stringbuilder
            var s = new StringBuilder();

            for (int i = 0; i < data.Length; i++)
            {
                s.Append(data[i].ToString("x2"));
            }

            result = s.ToString();

            return result.ToLower();
        }

        public Player LoginPlayer(string email, string password)
        {
            Player player = null;
            try
            {
                password = HashSha256(password);
                if (1 == playerAccessor.AuthenticatePlayer(email, password))
                {
                   
                    player = playerAccessor.SelectPlayerByEmail(email);
                    player.PlayerTitle = playerAccessor.SelectPlayerTitlesByPlayerID(player.PlayerID);
                }
                else
                {
                    throw new ApplicationException("Bad Username or Password");
                }
            }
            catch (Exception ex)
            {

                throw new ApplicationException("Login Failed", ex);
            }

            return player;
        }

        public bool ResetPassword(int playerID, string password, string oldPassword)
        {
            throw new NotImplementedException();
        }
    }
}
