﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DataAccessInterfaces;
using DataObjects;
using DataAccessLayer;

namespace LogicLayerInterfaces
{
    public interface IGameManager
    {
        List<GameVM> RetrieveGamesByStatus(string status);
        GameVM RetrieveSpecificsForGameVM(GameVM gameVM);
    }
}
