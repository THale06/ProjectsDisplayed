﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LogicLayer;

namespace LogicLayerTests
{
    [TestClass]
    public class GamesManagerTests
    {
        private GameManager _gameManager = null;

        [TestInitialize]
        public void TestSetup()
        {
            _gameManager = new GameManager(new GameAccessorFake());

        }

        [TestMethod]
        public void TestRetrieveSpecificsForGameVMReturnsCorrectList()
        {
            // arrange 
            const string gameType = "RPG";
            const int expectedCount = 2;
            GameVM gameVM = new GameVM() { GameTypeID = gameType };
            int actualCount;

            // act

            gameVM = _gameManager.RetrieveSpecificsForGameVM(gameVM);
            actualCount = gameVM.Specifics.Count;

            // assert
            Assert.AreEqual(expectedCount, actualCount);
        }



        [TestMethod]
        [ExpectedException(typeof(ApplicationException))]
        public void TestRetrieveSpecificsForGameVMThrowsExceptionWithBadGameTypeID()
        {
            // arrange
            const string gameType = "Invalid";
            GameVM gameVM = new GameVM() { GameTypeID = gameType };

            // act
            gameVM = _gameManager.RetrieveSpecificsForGameVM(gameVM);

            // assert
        }


        [TestMethod]
        public void TestRetrieveGamesByStatusReturnCorrectList()
        {
            // arrange
            const string status = "Available";
            const int expectedResult = 3;
            int actualResult = 0;

            // act
            var games = _gameManager.RetrieveGamesByStatus(status);
            actualResult = games.Count;

            // assert
            Assert.AreEqual(expectedResult, actualResult);


        }
    }
}