﻿using LogicLayer;
using LogicLayerInterfaces;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using DataAccessFakes;
using DataObjects;

namespace LogicLayerTests
{
    [TestClass]
    public class PlayerManagerTests
    {
        IPlayerManager playerManager = null;

        [TestInitialize]
        public void TestSetup()
        {
            playerManager = new PlayerManager(new PlayerAccessorFake());
        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentException))]
        public void TestHashSHA256ThrowsExceptionForEmptyString()
        {
            // Arrange
            const string source = "";

            // Act
            playerManager.HashSha256(source);

            // Assert
            
        }

        [TestMethod]
        public void TestHashSHA256ReturnsCorrectHash()
        {
            // Arrange
            const string source = "newuser";
            const string expectedResult =
                "9c9064c59f1ffa2e174ee754d2979be80dd30db552ec03e7e327e9b1a4bd594e";
            string actualResult = "";

            // Act
            actualResult = playerManager.HashSha256(source);

            // Assert
            Assert.AreEqual(expectedResult, actualResult);
        }

        [TestMethod]
        public void TestLoginPlayerPassesWithCorrectEmailAndPassword()
        {
            // Arrange

            const string email = "jham@game.com";
            const string password = "newuser";
            int expectedResult = 999999;
            int actualResult = 0;

            // Act

            Player testPlayer = playerManager.LoginPlayer(email, password);
            actualResult = testPlayer.PlayerID;

            // Assert

            Assert.AreEqual(expectedResult, actualResult);

        }

        [TestMethod]
        [ExpectedException(typeof(ApplicationException))]
        public void TestLoginPlayerFailsWithBadEmail()
        {
            // Arrange

            const string email = "bad-jham@game.com";
            const string password = "newuser";
     
            // Act

            playerManager.LoginPlayer(email, password);
            
        }

        [TestMethod]
        [ExpectedException(typeof(ApplicationException))]
        public void TestLoginPlayerFailsWithBadPassword()
        {
            // Arrange

            const string email = "jham@game.com";
            const string password = "bad-player";
            
            // Act

            playerManager.LoginPlayer(email, password);
            
        }
    }
}
