IF EXISTS(SELECT 1 FROM master.dbo.sysdatabases
			WHERE name = 'game_inventory')
BEGIN
	DROP DATABASE game_inventory
	print '' print '*** dropping database game_inventory'
END
GO

print '' print '*** creating database game_inventory'
GO
CREATE DATABASE game_inventory
GO

print '' print '*** using database game_inventory'
GO
USE [game_inventory]
GO

/* Player table */
print '' print '*** creating Player table'
GO
CREATE TABLE [dbo].[Player]
(
	[PlayerID]		[int] IDENTITY(100000, 1)	NOT NULL,
	[FirstName]		[nvarchar](25)				NOT NULL,
	[LastName]		[nvarchar](50)				NOT NULL,
	[Phone]			[nvarchar](13)				NOT NULL,
	[Email]			[nvarchar](100)				NOT NULL,
	[PasswordHash]	[nvarchar](100)				NOT NULL DEFAULT 
		'9c9064c59f1ffa2e174ee754d2979be80dd30db552ec03e7e327e9b1a4bd594e',
	[Active]		[bit]						NOT NULL DEFAULT 1,
	CONSTRAINT		[pk_PlayerID] PRIMARY KEY ([PlayerID]),
	CONSTRAINT		[ak_Email] UNIQUE ([Email])
)
GO

/* Player test records */
print '' print '*** creating player test records'
GO
INSERT INTO [dbo].[Player]
		([FirstName], [LastName], [Phone], [Email])
	VALUES	
		('Anthoney', 'Hale', '3195559121', 'ahale@game.com'),
		('John', 'Smith', '3195558474', 'jsmith@game.com'),
		('Alice', 'Jones', '3195558445', 'ajones@game.com'),
		('David' , 'Williams', '3195554545', 'dwilliams@game.com')

GO		

/* Title table */
print '' print '*** creating title table'
GO
CREATE TABLE [dbo].[Title]
(
	[TitleID]		[nvarchar](50)			NOT NULL,
	[Description]	[nvarchar](100)			NOT NULL,
	CONSTRAINT		[pk_RoleID] PRIMARY KEY ([TitleID])
)
GO

/* create sample title records */
print '' print '*** creating sample title records'
GO
INSERT INTO [dbo].[Title]
		([TitleID], [Description])
	VALUES
		('Admin', 'Administers player accounts'),
		('Manager', 'Manages game inventory'),
		('Rental', 'Rents games to customers'),
		('Return', 'Marks games as returned'),
		('Inspection', 'Inspects games before prep'),
		('Prep', 'Prepares games for rental')
GO

/* PlayerTitle table */
print '' print '*** creating PlayerTitle join table'
GO
CREATE TABLE [dbo].[PlayerTitle] 
(
	[PlayerID]			[int] 						NOT NULL,
	[TitleID]			[nvarchar](50)				NOT NULL,
	CONSTRAINT 			[fk_PlayerTitle_PlayerID] 
		FOREIGN KEY ([PlayerID]) REFERENCES [dbo].[Player]([PlayerID]),
	CONSTRAINT 			[fk_PlayerRole_TitleID] 
		FOREIGN KEY ([TitleID]) REFERENCES [dbo].[Title]([TitleID]),
	CONSTRAINT			[pk_PlayerTitle]
		PRIMARY KEY ([PlayerID], [TitleID])
)
GO

/* create sample PlayerTitle records */
print '' print '*** creating sample PlayerTitle records'
GO
INSERT INTO [dbo].[PlayerTitle]
		([PlayerID], [TitleID])
	VALUES
		(100000, 'Admin'),
		(100000, 'Manager'),
		(100001, 'Rental'),
		(100001, 'Return'),
		(100002, 'Inspection'),
		(100003, 'Prep')
	
GO

/* login-related stored procedure */
print '' print '*** creating sp_authenticate_player'
GO
CREATE PROCEDURE [dbo].[sp_authenticate_player]
(
	@Email 				[nvarchar](100),
	@PasswordHash		[nvarchar](100)
)
AS
	BEGIN
		SELECT 	COUNT([PlayerID]) as 'Authenticated'
		FROM	[Player]
		WHERE	@Email = [Email]
		  AND	@PasswordHash = [PasswordHash]
		  AND	ACTIVE = 1
	END
GO

print '' print '*** creating sp_select_player_by_email'
GO
CREATE PROCEDURE [dbo].[sp_select_player_by_email]
(
	@Email		[nvarchar](100)
)
AS
	BEGIN
		SELECT 	[PlayerID], [FirstName], [LastName], 
					[Phone], [Email], [Active]
		FROM	[Player]
		WHERE	@Email = [Email]
	END
GO

print '' print '*** creating sp_select_playertitle_by_playerid'
GO
CREATE PROCEDURE [dbo].[sp_select_playertitle_by_playerid]
(
	@PlayerID		[int]
)
AS
	BEGIN
		SELECT 	[TitleID]
		FROM	[PlayerTitle]
		WHERE	@PlayerID = [PlayerID]
	END
GO

print '' print '*** creating sp_update_passwordHash'
GO
CREATE PROCEDURE [dbo].[sp_update_passwordHash]
(
	@PlayerID				[int],
	@PasswordHash			[nvarchar](100),
	@OldPasswordHash		[nvarchar](100)
)
AS
	BEGIN
		UPDATE 	[Player]
		  SET 	[PasswordHash] = 	@PasswordHash
		WHERE	@PlayerID = 		[PlayerID]
		  AND	@OldPasswordHash = 	[PasswordHash]
		  
		RETURN 	@@ROWCOUNT
	END
GO

/* Game Stuff */

/* GameType Table */

print '' print '*** creating gametype table'	
GO
CREATE TABLE [dbo].[GameType] (
	[GameTypeID]	[nvarchar](25)				NOT NULL,
	[Description]	[nvarchar](1000)			NOT NULL,
	CONSTRAINT [pk_GameTypeID] PRIMARY KEY([GameTypeID])
)
GO

print '' print '*** creating gametype records'	
GO
INSERT INTO [dbo].[GameType]
		([GameTypeID], [Description])
	VALUES
		('RPG', 'Role Play Game.'),
		('FPS', 'First Person Shooter Game'),
		('Strategy', 'Strategy Game')
GO

/* Specifics table */
print '' print '*** creating specifics table'
GO
CREATE TABLE [dbo].[specifics] (
	[SpecificsID]	[int] IDENTITY(100000, 1) 	NOT NULL,
	[GameTypeID]	[nvarchar](25)				NOT NULL,
	[Description]	[nvarchar](1000)			NOT NULL,
	CONSTRAINT [pk_SpecificsID] PRIMARY KEY([SpecificsID]),
	CONSTRAINT [fk_GameTypeID_Specifics] FOREIGN KEY([GameTypeID])
		REFERENCES [GameType]([GameTypeID]),
)
GO

print '' print '*** inserting sample Specifics records'	
GO
INSERT INTO [dbo].[Specifics]
		([GameTypeID], [Description])
	VALUES
	('RPG', 'Single-player RPGs'),
	('RPG', 'Massive multiplayer online'),
	('FPS', 'Fast paced action'),
	('FPS', 'strategic survival'),
	('Strategy', 'Real-time strategy (RTS)'),
	('Strategy', 'Turn-based Tactical role-playing')
GO

/* GameStatus Table */
print '' print '*** creating GameStatus table'	
GO
CREATE TABLE [dbo].[GameStatus] (
	[GameStatusID]	[nvarchar](25)			NOT NULL,
	[Description]	[nvarchar](100)			NULL,
	CONSTRAINT [pk_GameStatusID] PRIMARY KEY([GameStatusID])
)
GO

print '' print '*** inserting sample GameStatus records'	
GO
INSERT INTO [dbo].[GameStatus]
		([GameStatusID], [Description])
	VALUES
	('Available', 'Ready to be rented.'),
	('Rented', 'Checked out, not currently available.'),
	('Needs Prep', 'needs cleaned.'),
	('Needs Repair', 'Game isnt working.')
GO

/* Game Table */
print '' print '*** creating Game table'	
GO
CREATE TABLE [dbo].[Game] (
	[GameID]		[int] IDENTITY(100000, 1)	NOT NULL,
	[Title]			[nvarchar](50)				NOT NULL,
	[GameTypeID]	[nvarchar](25)				NOT NULL,
	[GameStatusID]	[nvarchar](25)				NOT NULL,
	[Active]		[bit]						NOT NULL DEFAULT 1,
	CONSTRAINT [pk_GameID] PRIMARY KEY([GameID]),
	CONSTRAINT [fk_GameStatus_ID] FOREIGN KEY([GameStatusID])
		REFERENCES [GameStatus]([GameStatusID]),
	CONSTRAINT [fk_GameType_ID] FOREIGN KEY([GameTypeID])
		REFERENCES [GameType]([GameTypeID])
)
GO

print '' print '*** inserting sample Game records'	
GO
INSERT INTO [dbo].[Game]
		([Title], [GameTypeID], [GameStatusID])
	VALUES
	('Final Fantasy 7', 'FPS', 'Available'),
	('Call of Duty; Modern Warfare 2', 'FPS', 'Available'),
	('The Last Roundup', 'RPG', 'Available'),
	('World of Warcraft', 'RPG', 'Available'),
	('Age of Empires II', 'Strategy', 'Available'),
	('Romance of the Three Kingdoms XIV', 'Strategy', 'Available')
GO

print '' print '*** creating sp_select_games_by_gamestatusid'	
GO
CREATE PROCEDURE [dbo].[sp_select_games_by_gamestatusid]
(
	@GameStatusID [nvarchar](25)
)
AS
BEGIN
	SELECT 	[GameID], [Title], [GameTypeID], [GameStatusID], [Active]
	FROM	[dbo].[Game]
	WHERE	@GameStatusID = [GameStatusID]
	  AND	[Active] = 1
END
GO

print '' print '*** creating sp_select_specifics_by_gametypeid'	
GO
CREATE PROCEDURE [dbo].[sp_select_specifics_by_gametypeid]
(
	@GameTypeID [nvarchar](25)
)
AS
BEGIN
	SELECT 	[Description]
	FROM	[dbo].[Specifics]
	WHERE	@GameTypeID = [GameTypeID]
END


/* BoardGame Stuff */

/* BoardGameType Table */

print '' print '*** creating BoardGameType table'	
GO
CREATE TABLE [dbo].[BoardGameType] (
	[BoardGameTypeID]	[nvarchar](25)				NOT NULL,
	[Description]		[nvarchar](1000)			NOT NULL,
	CONSTRAINT [pk_BoardGameTypeID] PRIMARY KEY([BoardGameTypeID])
)
GO

print '' print '*** creating BoardGameType records'	
GO
INSERT INTO [dbo].[BoardGameType]
		([BoardGameTypeID], [Description])
	VALUES
		('Strategy', 'Strategy Game'),
		('Deck Building', 'Multi-Player Deck Building Game'),
		('Card', 'Card Based Game')
GO

/* Board Game Specifics table */
print '' print '*** creating bgspecifics table'
GO
CREATE TABLE [dbo].[bgspecifics] (
	[BGSpecificsID]		[int] IDENTITY(100000, 1) 	NOT NULL,
	[BoardGameTypeID]	[nvarchar](25)				NOT NULL,
	[Description]		[nvarchar](1000)			NOT NULL,
	CONSTRAINT [pk_BGSpecificsID] PRIMARY KEY([BGSpecificsID]),
	CONSTRAINT [fk_BoardGameTypeID_BGSpecifics] FOREIGN KEY([BoardGameTypeID])
		REFERENCES [BoardGameType]([BoardGameTypeID]),
)
GO

print '' print '*** inserting sample BG Specifics records'	
GO
INSERT INTO [dbo].[BGSpecifics]
		([BoardGameTypeID], [Description])
	VALUES
	('Strategy', 'Card Based Army Builder'),
	('Deck Building', 'Drop in Deck Building Experence'),
	('Card', 'Fast Paced Card Game')
GO


/* BoardGameStatus Table */
print '' print '*** creating BoardGameStatus table'	
GO
CREATE TABLE [dbo].[BoardGameStatus] (
	[BoardGameStatusID]	[nvarchar](25)			NOT NULL,
	[Description]		[nvarchar](100)			NULL,
	CONSTRAINT [pk_BoardGameStatusID] PRIMARY KEY([BoardGameStatusID])
)
GO

print '' print '*** inserting sample BoardGameStatus records'	
GO
INSERT INTO [dbo].[BoardGameStatus]
		([BoardGameStatusID], [Description])
	VALUES
	('Available', 'Ready to be rented.'),
	('Rented', 'Checked out, not currently available.'),
	('Needs Prep', 'needs cleaned.'),
	('Needs Replaced', 'Game is missing pieces')
GO

/* BoardGame Table */
print '' print '*** creating BoardGame table'	
GO
CREATE TABLE [dbo].[BoardGame] (
	[BoardGameID]		[int] IDENTITY(100000, 1)	NOT NULL,
	[Title]				[nvarchar](50)				NOT NULL,
	[BoardGameTypeID]	[nvarchar](25)				NOT NULL,
	[BoardGameStatusID]	[nvarchar](25)				NOT NULL,
	[Active]			[bit]						NOT NULL DEFAULT 1,
	CONSTRAINT [pk_BoardGameID] PRIMARY KEY([BoardGameID]),
	CONSTRAINT [fk_BoardGameStatus_ID] FOREIGN KEY([BoardGameStatusID])
		REFERENCES [BoardGameStatus]([BoardGameStatusID]),
	CONSTRAINT [fk_BoardGameType_ID] FOREIGN KEY([BoardGameTypeID])
		REFERENCES [BoardGameType]([BoardGameTypeID])
)
GO


print '' print '*** inserting sample BoardGame records'	
GO
INSERT INTO [dbo].[BoardGame]
		([Title], [BoardGameTypeID], [BoardGameStatusID])
	VALUES
	('Settlers of Catan', 'Strategy', 'Available'),
	('Legendary', 'Deck Building', 'Available'),
	('Wxploding Kittens', 'Card', 'Available'),
	('Betrayal at House on the Hill', 'Strategy', 'Available'),
	('Terraforming Mars', 'Strategy', 'Available'),
	('Smash Up', 'Deck Building', 'Available')
GO


print '' print '*** creating sp_select_boardgames_by_boardgamestatusid'	
GO
CREATE PROCEDURE [dbo].[sp_select_games_by_boardgamestatusid]
(
	@BoardGameStatusID [nvarchar](25)
)
AS
BEGIN
	SELECT 	[BoardGameID], [Title], [BoardGameTypeID], [BoardGameStatusID], [Active]
	FROM	[dbo].[BoardGame]
	WHERE	@BoardGameStatusID = [BoardGameStatusID]
	  AND	[Active] = 1
END
GO

print '' print '*** creating sp_select_bgspecifics_by_boardgametypeid'	
GO
CREATE PROCEDURE [dbo].[sp_select_bgspecifics_by_boardgametypeid]
(
	@BoardGameTypeID [nvarchar](25)
)
AS
BEGIN
	SELECT 	[Description]
	FROM	[dbo].[BGSpecifics]
	WHERE	@BoardGameTypeID = [BoardGameTypeID]
END


/* Movie Stuff */
/* Movie Type Table */

print '' print '*** creating MovieType table'	
GO
CREATE TABLE [dbo].[MovieType] (
	[MovieTypeID]		[nvarchar](25)				NOT NULL,
	[Description]		[nvarchar](1000)			NOT NULL,
	CONSTRAINT [pk_MovieTypeID] PRIMARY KEY([MovieTypeID])
)
GO

print '' print '*** creating MovieType records'	
GO
INSERT INTO [dbo].[MovieType]
		([MovieTypeID], [Description])
	VALUES
		('Horror', 'Scary Movie'),
		('Comedy', 'Funny Movie'),
		('Action', 'Action Movie')
GO

/* Movie Specifics table */
print '' print '*** creating moviespecifics table'
GO
CREATE TABLE [dbo].[MovieSpecifics] (
	[MovieSpecificsID]	[int] IDENTITY(100000, 1) 	NOT NULL,
	[MovieTypeID]		[nvarchar](25)				NOT NULL,
	[Description]		[nvarchar](1000)			NOT NULL,
	CONSTRAINT [pk_MovieSpecificsID] PRIMARY KEY([MovieSpecificsID]),
	CONSTRAINT [fk_MovieTypeID_MovieSpecifics] FOREIGN KEY([MovieTypeID])
		REFERENCES [MovieType]([MovieTypeID]),
)
GO

print '' print '*** inserting sample MovieSpecifics records'	
GO
INSERT INTO [dbo].[MovieSpecifics]
		([MovieTypeID], [Description])
	VALUES
	('Horror', 'Killer/Thriller'),
	('Comedy', 'Will make the whole family laugh'),
	('Action', 'Action Packed')
GO

/* MovieStatus Table */
print '' print '*** creating MovieStatus table'	
GO
CREATE TABLE [dbo].[MovieStatus] (
	[MovieStatusID]	[nvarchar](25)			NOT NULL,
	[Description]	[nvarchar](100)			NULL,
	CONSTRAINT [pk_MovieStatusID] PRIMARY KEY([MovieStatusID])
)
GO

print '' print '*** inserting sample MovieStatus records'	
GO
INSERT INTO [dbo].[MovieStatus]
		([MovieStatusID], [Description])
	VALUES
	('Available', 'Ready to be rented.'),
	('Rented', 'Checked out, not currently available.'),
	('Needs Prep', 'needs cleaned.'),
	('Needs Replace', 'Movie doesnt work')
GO

/* Movie Table */
print '' print '*** creating Movie table'	
GO
CREATE TABLE [dbo].[Movie] (
	[MovieID]			[int] IDENTITY(100000, 1)	NOT NULL,
	[Title]				[nvarchar](50)				NOT NULL,
	[MovieTypeID]		[nvarchar](25)				NOT NULL,
	[MovieStatusID]		[nvarchar](25)				NOT NULL,
	[Active]			[bit]						NOT NULL DEFAULT 1,
	CONSTRAINT [pk_MovieID] PRIMARY KEY([MovieID]),
	CONSTRAINT [fk_MovieStatus_ID] FOREIGN KEY([MovieStatusID])
		REFERENCES [MovieStatus]([MovieStatusID]),
	CONSTRAINT [fk_MovieType_ID] FOREIGN KEY([MovieTypeID])
		REFERENCES [MovieType]([MovieTypeID])
)
GO

print '' print '*** inserting sample Movie records'	
GO
INSERT INTO [dbo].[Movie]
		([Title], [MovieTypeID], [MovieStatusID])
	VALUES
	('The Exorcist', 'Horror', 'Available'),
	('Avatar', 'Action', 'Available'),
	('The Batman', 'Action', 'Available'),
	('Step Brothers', 'Comedy', 'Available'),
	('Bridesmaids', 'Comedy', 'Available'),
	('The Silence of the Lambs', 'Horror', 'Available')
GO


print '' print '*** creating sp_select_movies_by_moviestatusid'	
GO
CREATE PROCEDURE [dbo].[sp_select_games_by_moviestatusid]
(
	@MovieStatusID [nvarchar](25)
)
AS
BEGIN
	SELECT 	[MovieID], [Title], [MovieTypeID], [MovieStatusID], [Active]
	FROM	[dbo].[Movie]
	WHERE	@MovieStatusID = [MovieStatusID]
	  AND	[Active] = 1
END
GO

print '' print '*** creating sp_select_moviespecifics_by_movietypeid'	
GO
CREATE PROCEDURE [dbo].[sp_select_moviespecifics_by_movietypeid]
(
	@MovieTypeID [nvarchar](25)
)
AS
BEGIN
	SELECT 	[Description]
	FROM	[dbo].[MovieSpecifics]
	WHERE	@MovieTypeID = [MovieTypeID]
END



print '' print '*** creating Additional things'

print '' print '*** creating sp_rent_game'	
GO
CREATE PROCEDURE [dbo].[sp_rent_game]
(
	@GameID [int]
)
AS
BEGIN
	DELETE FROM	[dbo].[Game]
	WHERE  GameID = @GameID
END
